Changelog
=========

.. contents::
    :local:
    :depth: 2

0.1.2
-----
- Add Python-3.7 support

0.1.1
-----
- Appended changelog.rst
- Fixes in readme.rst

0.1.0
-----

- Initial version
